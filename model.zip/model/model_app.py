import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
import tensorflow as tf
from tensorflow.keras.models import Sequential, model_from_json
from tensorflow.keras.layers import Input, Dense, Activation
import json

#Loading and preparing the data

# kaggle data loaded from github repo
songs = pd.read_csv('https://raw.githubusercontent.com/Jllin50/DS/master/data/song_data.csv')
song_info = pd.read_csv('https://raw.githubusercontent.com/Jllin50/DS/master/data/song_info.csv')

#cleaning songs df
songs = songs.rename(columns={'audio_valence': 'valence'})
songs.insert(loc=1, column='song_artist', value=song_info['artist_name'])
songs = songs.drop(labels=['song_popularity', 'song_duration_ms', 'key', 'audio_mode'], axis=1)
cols = ['song_name', 'song_artist', 'danceability', 'energy', 'loudness', 'speechiness', 'acousticness', 'instrumentalness', 'liveness', 'valence', 'tempo', 'time_signature']
songs = songs[cols]

#creating a scaled features df from the song df
features = songs.drop(labels=['song_name', 'song_artist'], axis=1)
scaler = MinMaxScaler()
features_scaled = scaler.fit_transform(features)

# implementing kmeans
np.random.seed(42)
kmeans = KMeans(n_clusters=7)
kmeans.fit(features_scaled)

#cluster predictions for each song
y_kmeans = kmeans.predict(features_scaled)

#adding song kmean group label to song df 
songs['label'] = y_kmeans
songs = songs.sample(frac=1)

# #train test split on data
# X_train, X_test, y_train, y_test = train_test_split(features_scaled, y_kmeans, test_size=0.2)

# y_train_binary = to_categorical(y_train)
# y_test_binary = to_categorical(y_test)

# #neural network
# model = Sequential([
#     Input(shape=(X_train.shape[1])),
#     Dense(128, activation='relu'),
#     Dense(64, activation='relu'),
#     Dense(32, activation='relu'),
#     Dense(7, activation='softmax')
# ])

# inputs = Input(shape=(10,))

# model.compile('nadam', 'categorical_crossentropy', metrics=['accuracy'])

# model.fit(X_train, y_train_binary, epochs=10, batch_size=16, validation_split=.2)

# load json and create model
json_file = open('spotify_model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
model = model_from_json(loaded_model_json)
# load weights into new model
model.load_weights("spotify_model.h5")
print("Loaded model from disk")

#input = [name, artist, danceability, energy, loudness, speechiness, acousticness, instrumentalness, liveness, valence, tempo, time_signature] 
#example input list  ['rockstar (feat. 21 Savage)', 'Post Malone', 0.585, 0.52, -6.136, 0.0712, 0.124, 7.01e-05, 0.131, 0.129, 159.801, 4]

#FORMAT FOR INPUT DATA
#input = [name, artist, danceability, energy, loudness, speechiness, acousticness, instrumentalness, liveness, valence, tempo, time_signature] 
#example input list  ['rockstar (feat. 21 Savage)', 'Post Malone', 0.585, 0.52, -6.136, 0.0712, 0.124, 7.01e-05, 0.131, 0.129, 159.801, 4]

#global input_scaled = np.empty((1,10)) used for modifying df in results dataframe

#input_scaled = adj_input(a_list)
#scaled_songs = scaled_songs(adj_input(a_list))
#neighbors = find_neighbors(scaled_songs(adj_input(a_list)))
#track_info = dict({'artist': a_list[1], 'song': a_list[0]}) in main function

#main function
def take_ten(a_list):
  '''takes input list for 1 song and returns a json file with the 10 most similar songs''' 
  global track_info

  #setting static variables for results_dataframe function
  input_scaled = np.empty((1,10))
  track_info = dict({'artist': a_list[1], 'song': a_list[0]})

  #saving results as json
  results_df = results_dataframe(find_neighbors(scaled_songs(adj_input(a_list))))[['song_name', 'song_artist']]
  results_df.to_json('results.json', orient='records')
  with open('results.json') as json_file:
    json_data = json.load(json_file)

  return json_data

#sub functions
def adj_input(the_list):
    '''takes an input list and returns cleaned and scaled version'''
    global a_list

    a_list = the_list
    input_vector = a_list[2:]
    input_scaled = scaler.transform(np.array(input_vector).reshape(1, -1))
    return input_scaled

def scaled_songs(a_array):
    '''takes scaled input array and returns a df with scaled values'''
    global songs
    
    #filtering songs by predicted label of sample track
    songs = songs.sort_index()

    filtered_songs = songs[songs['label'] == model.predict_classes(a_array)[0]]

    # dropping unnecessary columns and renaming for readability

    songs_scaled = filtered_songs.join(pd.DataFrame(features_scaled)).drop(
    labels=features.columns, axis=1)

    songs_scaled = songs_scaled.rename(
    columns={0: features.columns[0],
             1: features.columns[1],
             2: features.columns[2],
             3: features.columns[3],
             4: features.columns[4],
             5: features.columns[5],
             6: features.columns[6],
             7: features.columns[7],
             8: features.columns[8],
             9: features.columns[9]})

    return songs_scaled 

def find_neighbors(a_df):
    '''takes scaled df and returns df filtered for songs near to sample '''
    global a_list

    # computing distance from sample track for each track in cluster

    a_df['distance'] = [(np.linalg.norm(
    a_df[features.columns][i:i+1] - adj_input(a_list))) 
    for i in range(0, len(a_df))]

    # filtering to only songs within a certain distance

    neighbors = a_df[a_df['distance'] < .2].sort_values('distance')

    return neighbors

def results_dataframe(neighbors):

    # turning input scaled to df
    global input_scaled
    global track_info

    # neighbors = find_neighbors(scaled_songs(adj_input(a_list)))

    input_scaled = pd.DataFrame(adj_input(a_list)).rename(
    columns={0: features.columns[0],
             1: features.columns[1],
             2: features.columns[2],
             3: features.columns[3],
             4: features.columns[4],
             5: features.columns[5],
             6: features.columns[6],
             7: features.columns[7],
             8: features.columns[8],
             9: features.columns[9]})

    # rejoining artist and title with song features

    results = pd.DataFrame(track_info, 
                       index=[0], 
                       columns=['song', 'artist']
                      ).rename(columns={'song': 'song_name',
                                        'artist': 'song_artist'}
                              )

    results = pd.concat([results, input_scaled], axis=1)

    results['label'] = model.predict_classes(input_scaled)
    
    # adding sample track to filtered songs

    results = pd.concat([results, neighbors])

    # dropping duplicates where name and artist are identical

    results = results.drop_duplicates(subset=['song_name', 'song_artist'])

    #return top 10 song names with artist
    result_df = pd.concat([results[:1], results.sample(10).sort_values('distance')])

    result_df = result_df[['song_name','song_artist']]

    result_df = pd.concat([results[:1], results.sample(10).sort_values('distance')])

    return result_df
