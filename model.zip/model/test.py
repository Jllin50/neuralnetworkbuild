from model_app import take_ten

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Dense, Activation

#example input 
#this is the format that the model_app function should recive data from flask 
the_list = ['rockstar (feat. 21 Savage)', 'Post Malone', 0.585, 0.52, -6.136, 0.0712, 0.124, 7.01e-05, 0.131, 0.129, 159.801, 4]

print(take_ten(the_list))